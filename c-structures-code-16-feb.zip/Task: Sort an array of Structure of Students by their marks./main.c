#include<stdio.h>
struct student 
{
    char name[10];
    int roll_num;
    float marks;
};

int main()
{
    struct student s[3] = 
    {
        {"Khush",12,75.5},{"Deep",30,55.2},{"Khushdeep",42,95.8}
    };
    for(int i=0 ; i<3 ; i++)
    {
        for(int j=i+1 ; j<3 ; j++)
        {
            if(s[i].marks > s[j].marks)
            {
                struct student temp = s[i];
                s[i]=s[j];
                s[j]=temp;
            }
        }
    }
    printf("Sorted By Marks : \n");
    for(int i=0 ; i<3 ; i++)
    {
        printf("\nStudent %d:\n",i+1);
        printf("Name: %s\n",s[i].name);
        printf("Roll No.: %d\n",s[i].roll_num);
        printf("Marks: %.2f\n",s[i].marks);
    }
    return 0;
}