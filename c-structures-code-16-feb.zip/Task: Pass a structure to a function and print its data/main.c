#include<stdio.h>
struct Employee
{
    char name[10];
    int id_number;
    float salary;
};

void display(struct Employee emp)
{
    printf("Employee Details: \n");
    printf("Name: %s\n",emp.name);
    printf("ID Number: %d\n",emp.id_number);
    printf("Salary: %.2f",emp.salary);
}
int main()
{
    struct Employee e1 = {"Khushdeep",42,95016};
    display(e1);
    return 0;
}