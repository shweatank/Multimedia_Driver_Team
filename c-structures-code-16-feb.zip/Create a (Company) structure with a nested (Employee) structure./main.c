#include<stdio.h>
struct Employee
{
    char name[50];
    int id;
    float salary;
};
struct Company
{
    char name[50];
    struct Employee emp;
};

int main()
{
    struct Company cmp = {"--Techdhaba.Ltd--",{"Khushdeep Insa",42,5000}};
    printf("Company Name: %s\n",cmp.name);
    printf("Employee Name: %s\n",cmp.emp.name);
    printf("ID: %d\n",cmp.emp.id);
    printf("Salary: %.2f",cmp.emp.salary);
    
    return 0;
}