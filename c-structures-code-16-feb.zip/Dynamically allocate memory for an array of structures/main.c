#include <stdio.h>
#include <stdlib.h>

struct Product {
    char name[50];
    float price;
};

int main() {
    int n;
    printf("Enter the number of products: ");
    scanf("%d", &n);

    struct Product *products = (struct Product *)malloc(n * sizeof(struct Product));

    // Input data
    for (int i = 0; i < n; i++) {
        printf("Enter product %d name: ", i + 1);
        scanf("%49s", products[i].name);
        printf("Enter product %d price: ", i + 1);
        scanf("%f", &products[i].price);
    }

    // Display data
    printf("\nProduct List:\n");
    for (int i = 0; i < n; i++) {
        printf("Name: %s, Price: %.2f\n", products[i].name, products[i].price);
    }

    free(products);
    return 0;
}
