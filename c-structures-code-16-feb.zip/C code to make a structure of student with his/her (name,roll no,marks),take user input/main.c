#include <stdio.h>

// Defining a structure for a student
struct Student {
    char name[50];
    int rollNumber;
    float marks;
};

int main() {
    // Declaring a structure variable
    struct Student student1;

    // Assigning values to structure members
    printf("Enter student's name: ");
    scanf("%49s", student1.name);

    printf("Enter roll number: ");
    scanf("%d", &student1.rollNumber);

    printf("Enter marks: ");
    scanf("%f", &student1.marks);

    // Displaying the structure data
    printf("\nStudent Details:\n");
    printf("Name: %s\n", student1.name);
    printf("Roll Number: %d\n", student1.rollNumber);
    printf("Marks: %.2f\n", student1.marks);

    return 0;
}
