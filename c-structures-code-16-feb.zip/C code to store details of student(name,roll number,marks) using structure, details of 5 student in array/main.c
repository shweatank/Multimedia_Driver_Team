#include<stdio.h>

struct student
{
    char name[50];
    int roll_number;
    float marks;
};

int main()
{
    struct student student[5];
    for(int i=0 ; i<5 ; i++)
    {
        printf("%d:\n",i+1);
        printf("Enter Student name: ");
        scanf("%s",student[i].name);
        printf("Enter Roll Number: ");
        scanf("%d",&student[i].roll_number);
        printf("Enter Marks: ");
        scanf("%f",&student[i].marks);
    }
    for(int i=0 ; i<5 ; i++)
    {
        printf("\nStudent %d\n",i+1);
        printf("Name: %s\n",student[i].name);
        printf("Roll Number: %d\n",student[i].roll_number);
        printf("Marks: %.2f",student[i].marks);
    }
    return 0;
}