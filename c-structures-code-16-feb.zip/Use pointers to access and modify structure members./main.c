#include<stdio.h>
struct student
{
    char name[20];
    int roll_num;
    float marks;
};

int main()
{
    struct student std = {"Khushdeep",5,55.2};
    struct student *ptr = &std;
    
    printf("Name: %s\n",ptr->name);
    printf("Roll number: %d\n",ptr->roll_num);
    printf("Makrks: %.2f\n\n",ptr->marks);
    
    printf("Modified Value: \n");
    ptr->marks=88.5;
    printf("Marks %.2f",ptr->marks);
    
    return 0;
}