#include<stdio.h>
#include<stdlib.h>
typedef struct ll
{
    int data;
    struct ll *next;
}node;

void insertAtBeginning(int data, node** head)
{
    node* newNode = malloc(sizeof(node));
    newNode->data = data;
    newNode->next = *head;
    *head = newNode;
}

void insertAtEnd(int data, node** head)
{
    node* newNode = malloc(sizeof(node));
    newNode->data = data;
    newNode->next = NULL;
    node* temp = *head;
    while(temp->next != NULL)
    {
        temp = temp->next;
    }
    temp->next = newNode;
}

void sortList(node** head)
{
    node* currentNode;
    node* nextNode;
    for(currentNode = *head ; currentNode != NULL ; currentNode = currentNode->next)
    {
        for(nextNode = currentNode->next ; nextNode != NULL ; nextNode = nextNode->next)
        {
            if(currentNode->data > nextNode->data)
            {
                int temp = currentNode->data;
                currentNode->data = nextNode->data;
                nextNode->data = temp;
            }
        }
    }
}

void printList(node* node)
{
    while(node != NULL)
    {
        printf("%d->",node->data);
        node = node->next;
    }
    printf("NULL");
}

int main()
{
    node* head = NULL;
    insertAtBeginning(51,&head);
    insertAtBeginning(86,&head);
    insertAtBeginning(45,&head);
    insertAtBeginning(06,&head);
    insertAtBeginning(200,&head);
    insertAtBeginning(10,&head);
    insertAtEnd(40,&head);
    sortList(&head);
    printList(head);
    
    return 0;
}