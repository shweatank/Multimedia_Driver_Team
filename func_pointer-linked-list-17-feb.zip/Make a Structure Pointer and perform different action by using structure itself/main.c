#include<stdio.h>
int add(int x, int y)
{
    return x+y;
}
int sub(int x, int y)
{
    return x-y;
}
int mul(int x, int y)
{
    return x*y;
}
float div(int x, int y)
{
    return x/y;
}

struct operation 
{
    int(*add)(int,int);
    int(*sub)(int,int);
    int(*mul)(int,int);
    float(*div)(int,int);
};

struct operation op = {
    .add=add,
    .sub=sub,
    .mul=mul,
    .div=div,
};
int main()
{
    printf("Addition: %d\n",add(5,2));
    printf("Subtraction: %d\n",sub(5,2));
    printf("Multiplication: %d\n",mul(5,2));
    printf("Division: %.2f\n",div(5,2));
    
    return 0;
}