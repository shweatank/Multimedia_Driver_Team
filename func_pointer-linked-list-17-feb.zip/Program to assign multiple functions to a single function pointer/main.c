#include<stdio.h>
int mul(int x,int y){ return x*y;}
int div(int x,int y){ return x/y;}

int main()
{
    int(*fp)(int,int);
    fp = mul;
    printf("Multiplication: %d\n",mul(5,2));
    fp = div;
    printf("Division: %d",div(6,2));
    
    return 0;
}