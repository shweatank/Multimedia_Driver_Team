#include<stdio.h>
int add(int x, int y)
{
    return x+y;
}

void compute(int x,int y,int(*fp)(int,int))
{
    printf("Result: %d",fp(x,y));
}

int main()
{
    compute(5,2,add);
    return 0;
}
