#include<stdio.h>
#include<stdlib.h>
typedef struct ll
{
    int data;
    struct ll *next;
}node;

void insertAtBeginning(int data, node** head)
{
    node* newNode = malloc(sizeof(node));
    newNode->data = data;
    newNode->next = *head;
    *head = newNode;
}

void insertAtEnd(int data, node** head)
{
    node* newNode = malloc(sizeof(node));
    newNode->data = data;
    newNode->next = NULL;
    node* temp = *head;
    while(temp->next != NULL)
    {
        temp = temp->next;
    }
    temp->next = newNode;
}

void reverse(node** head)
{
    node* temp1 = *head;
    node* temp2 = NULL;
    while(temp1 != NULL)
    {
        node* temp = temp1->next;
        temp1->next = temp2;
        temp2 = temp1;
        temp1 = temp;
    }
    *head=temp2;
}

void printList(node* node)
{
    while(node != NULL)
    {
        printf("%d->",node->data);
        node = node->next;
    }
    printf("NULL");
}

int main()
{
    node* head = NULL;
    insertAtBeginning(30,&head);
    insertAtBeginning(20,&head);
    insertAtBeginning(10,&head);
    insertAtEnd(40,&head);
    reverse(&head);
    printList(head);
    
    return 0;
}