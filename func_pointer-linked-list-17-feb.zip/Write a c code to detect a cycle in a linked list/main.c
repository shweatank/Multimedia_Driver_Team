#include<stdio.h>
#include<stdlib.h>

typedef struct ll
{
    int data;
    struct ll *next;
}node;

void insertAtBeginning(int newdata, node** head)
{
    node* newNode = malloc(sizeof(node));
    newNode->data = newdata;
    newNode->next = *head;
    *head = newNode;
}

void insertAtEnd(int newdata, node** head)
{
    node* newNode = malloc(sizeof(node));
    node* temp = *head;
    newNode->data = newdata;
    newNode->next = NULL;
    while(temp->next != NULL)
    {
        temp = temp->next;
    }
    temp->next = newNode;
}

int detectCycle(node* head)
{
    node* fast = head;
    node* slow = head;
    while(fast != NULL && fast->next != NULL)
    {
        slow = slow->next;
        fast = fast->next->next;
        if(slow==fast)
        {
            return 1;
        }
    }
    return 0;
}

void printList(node* node)
{
    while(node != NULL)
    {
        printf("%d->",node->data);
        node=node->next;
    }
    printf("NULL");
}

int main()
{
    node* head = NULL;
    insertAtBeginning(10,&head);
    insertAtBeginning(20,&head);
    insertAtBeginning(30,&head);
    insertAtBeginning(40,&head);
    insertAtEnd(50,&head);
    printList(head);
    head->next->next->next = head->next; //created cycle for testing
    if (detectCycle(head))
        printf("\nCycle detected in the linked list\n");
    else
        printf("\nNo cycle detected\n");
    return 0;
}