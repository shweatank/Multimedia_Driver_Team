#include<stdio.h>

int add(int x,int y){ return x+y; }
int sub(int x,int y){ return x-y; }
int mul(int x,int y){ return x*y; }
int div(int x,int y){ return x/y; }

int main()
{
    int(*operation[4])(int,int) = {add,sub,mul,div};
    int op, x=10,y=5;
    printf("Add:0  Sub:1  Mul:2  Div:3\n");
    printf("Enter operation: ");
    scanf("%d",&op);
    if(op>=0 && op<=3)
    {
        printf("Result: %d",operation[op](x,y));
    }
    else
    {
        printf("--Invalid operation--");
    }
    return 0;
}