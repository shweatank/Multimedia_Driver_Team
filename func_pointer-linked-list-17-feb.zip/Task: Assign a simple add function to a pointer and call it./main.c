#include<stdio.h>
int add(int x,int y)
{
    return x+y;
}
int main()
{
    int(*fp)(int a ,int b) = add;
    int result = fp(5,2);
    printf("Sum: %d",result);
    return 0;
}