#include<stdio.h>
int add(int x,int y){return x+y;}
int sub(int x,int y){return x-y;}
int mul(int x,int y){return x*y;}
int div(int x,int y){return x/y;}

int main()
{
    int(*fp[4])(int,int) = {add,sub,mul,div};
    printf("Addition: %d\n",add(5,2));
    printf("Subtraction: %d\n",sub(5,2));
    printf("Multiplication: %d\n",mul(5,2));
    printf("Division: %d",div(5,2));
    
    return 0;
}