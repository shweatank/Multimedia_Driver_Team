#include<stdio.h>
#include<stdlib.h>
int main()
{
    int a[5];
    for(int i=0 ; i<5 ; i++)
    {
        printf("Enter the element %d:",i+1);
        scanf("%d",&a[i]);
    }
    printf("Array : ");
    for(int i=0 ; i<5 ; i++)
    {
        printf("%d ",a[i]);
    }
    int *ptr;
    ptr = (int*)malloc(5*sizeof(int));
    if(ptr==NULL)
    {
        printf("Error in allocating");
    }
    for(int i=0 ; i<5 ; i++)
    {
        ptr[i]=a[i];
    }
    printf("\nArray after allocating : ");
    for(int i=0 ; i<5 ; i++)
    {
        printf("%d ",ptr[i]);
    }
    free(ptr);
    return 0;
}