#include<stdio.h>
#include<stdlib.h>

// Define the node structure
typedef struct ll {
    int data;
    struct ll* next;
} node;

// Function to insert at the beginning
void insertAtBeginning(int data, node** head) {
    node* newNode = malloc(sizeof(node));
    newNode->data = data;
    newNode->next = *head;
    *head = newNode;
}

// Function to insert at the end
void insertAtEnd(int data, node** head) {
    node* newNode = malloc(sizeof(node));
    newNode->data = data;
    newNode->next = NULL;

    if (*head == NULL) {
        *head = newNode;
        return;
    }

    node* temp = *head;
    while (temp->next != NULL) {
        temp = temp->next;
    }
    temp->next = newNode;
}

// Function to print the linked list
void printList(node* node) {
    while (node != NULL) {
        printf("%d->", node->data);
        node = node->next;
    }
    printf("NULL\n");
}

// Function to sort the linked list
void sortList(node** head) {
    if (*head == NULL || (*head)->next == NULL) {
        return; // No sorting needed for an empty or single-node list
    }

    node* current;
    node* nextNode;
    int temp;

    for (current = *head; current != NULL; current = current->next) {
        for (nextNode = current->next; nextNode != NULL; nextNode = nextNode->next) {
            if (current->data > nextNode->data) {
                // Swap data
                temp = current->data;
                current->data = nextNode->data;
                nextNode->data = temp;
            }
        }
    }
}

void sortListt(node** head)
{
    if(*head == NULL || (*head)->next == NULL)
    {
        return;
    }
    
    node* current;
    node* newNode;
    int temp;
    for(current = *head ; current != NULL ; current = current->next)
    {
        for(newNode = current->next ; newNode != NULL ; newNode = newNode->next)
        {
            if(current->data > newNode->data)
            {
                temp = current->data;
                current->data = newNode->data;
                newNode->data = temp;
            }
        }
    }
}

void sortLList(node** head)
{
    if(*head == NULL || (*head)->next == NULL)
    {
        return;
    }
     node* current;
     node* newNode;
     int temp;
     for(current = *head ; current != NULL ; current = current->next)
     {
        for(newNode = current->next ; newNode != NULL ; newNode = newNode->next)
        {
            if(current->data > newNode->data)
            {
                temp = current->data;
                current->data = newNode->data;
                newNode->data = temp;
            }
        }
     }
}
// Main function
int main() {
    node* head = NULL;

    insertAtBeginning(60, &head);
    insertAtBeginning(1, &head);
    insertAtBeginning(170, &head);
    insertAtEnd(40, &head);

    printf("Original List: ");
    printList(head);

    // Sort the list
    sortLList(&head);

    printf("Sorted List: ");
    printList(head);

    return 0;
}
