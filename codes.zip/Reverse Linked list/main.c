#include<stdio.h>
#include<stdlib.h>

typedef struct ll
{
    int data;
    struct ll *next;
}node;

void insertAtBeginning(int newdata, node** head)
{
    node* newNode = malloc(sizeof(node));
    newNode->data = newdata;
    newNode->next = *head;
    *head = newNode;
}

void insertAtEnd(int newdata, node** head)
{
    node* newNode = malloc(sizeof(node));
    node* temp = *head;
    newNode->data = newdata;
    newNode->next = NULL;
    while(temp->next != NULL)
    {
        temp = temp->next;
    }
    temp->next = newNode;
}

void Reverse(node** head)
{
    node* temp1 = *head;
    node* temp2 = NULL;
    while(temp1 != NULL)
    {
        node*temp = temp1->next;
        temp1->next = temp2;
        temp2 = temp1;
        temp1 = temp;
    }
    *head = temp2;
}

void delete(int data, node** head)
{
    node* temp = *head;
    while(temp->next->data != data)
    {
        temp = temp->next;
    }
        temp->next = temp->next->next;
}

void printList(node* node)
{
    while(node != NULL)
    {
        printf("%d->",node->data);
        node=node->next;
    }
    printf("NULL");
}

int main()
{
    node* head = NULL;
    insertAtBeginning(10,&head);
    insertAtBeginning(20,&head);
    insertAtBeginning(30,&head);
    insertAtBeginning(40,&head);
    insertAtEnd(50,&head);
    printf("Normal LL : ");
    printList(head);
    printf("\n");
    printf("Reversed LL : ");
    Reverse(&head);
    printList(head);
    printf("\nDeleting data : ");
    delete(20,&head);
    printList(head);
    
    return 0;
}