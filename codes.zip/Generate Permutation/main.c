#include <stdio.h>
#include <string.h>

// Function to swap two characters
void swap(char *x, char *y) {
    char temp = *x;
    *x = *y;
    *y = temp;
}

// Function to generate permutations
void generatePermutations(char str[], int start, int end) {
    if (start == end) {
        printf("%s\n", str);
    } else {
        for (int i = start; i <= end; i++) {
            // Swap the current character with the starting character
            swap(&str[start], &str[i]);

            // Recurse for the remaining substring
            generatePermutations(str, start + 1, end);

            // Backtrack (restore the original order)
            swap(&str[start], &str[i]);
        }
    }
}

int main() {
    char str[20];

    // Input the string from the user
    printf("Enter a string: ");
    scanf("%s", str);

    int len = strlen(str);

    printf("All permutations of the string are:\n");
    generatePermutations(str, 0, len - 1);

    return 0;
}
