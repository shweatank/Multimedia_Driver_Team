#include <stdio.h>
#include <stdlib.h>

int main() {
    char *str = NULL;
    char ch;
    int size = 1, i = 0;

    // Allocate initial memory
    str = (char *)malloc(size * sizeof(char));
    if (str == NULL) {
        printf("Memory allocation failed\n");
        return 1;
    }

    printf("Enter a string (Press Enter to finish):\n");

    // Read characters one by one
    while ((ch = getchar()) != '\n') {
        str[i++] = ch;

        // Reallocate memory if needed
        if (i >= size) {
            size++;
            str = (char *)realloc(str, size * sizeof(char));
            if (str == NULL) {
                printf("Memory allocation failed\n");
                return 1;
            }
        }
    }
    str[i] = '\0'; // Null-terminate the string

    printf("You entered: %s\n", str);

    // Free the allocated memory
    free(str);

    return 0;
}
