#include <stdio.h>

// Define the size of the simulated linked list
#define SIZE 5

typedef struct {
    int data[SIZE];  // Array to store the linked list data
    int head;        // Index of the head of the list
    int size;        // Number of elements in the list
} LinkedList;

// Function to reverse the data in the simulated linked list
void reverseLinkedList(LinkedList* list) {
    int start = 0;
    int end = list->size - 1;

    // Swap the data from start to end
    while (start < end) {
        int temp = list->data[start];
        list->data[start] = list->data[end];
        list->data[end] = temp;

        start++;
        end--;
    }
}

// Function to print the simulated linked list
void printLinkedList(LinkedList* list) {
    for (int i = 0; i < list->size; i++) {
        printf("%d -> ", list->data[i]);
    }
    printf("NULL\n");
}

int main() {
    // Initialize the simulated linked list
    LinkedList list = {
        .data = {10, 20, 30, 40, 50},
        .head = 0,
        .size = SIZE
    };

    printf("Original List: ");
    printLinkedList(&list);

    reverseLinkedList(&list);

    printf("Reversed List: ");
    printLinkedList(&list);

    return 0;
}
