#include<stdio.h>
#include<string.h>

void reverseWord(char s[], int start, int end)
{
    char temp;
    while(start<end)
    {
        temp = s[start];
        s[start] = s[end];
        s[end] = temp;
        start++;
        end--;
    }
}
void reverseEachWord(char a[])
{
    int start=0;
    int end=0;
    int len = strlen(a);
    while(end<=len)
    {
        if(a[end] == ' ' || a[end] == '\0')
        {
            reverseWord(a,start,end-1);
            start = end+1;
        }
        end++;
    }
}
int main()
{
    char str[50] = "My name is Khushdeep";
    reverseEachWord(str);
    printf(str);
    return 0;
}
